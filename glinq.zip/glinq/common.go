package glinq

import "errors"

var (
	ErrorCannotFound = errors.New("未找到对应元素")
)
